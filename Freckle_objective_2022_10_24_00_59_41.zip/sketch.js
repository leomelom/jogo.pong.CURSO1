//sons do jogo
let raquetada;
let ponto;
let trilha;

//pontuacao
let meuspontos =0; pontosdele =0;

// variaveis da bola;
let xdabola = 100; let ydabola = 200; let diametro = 10; let raio = diametro/2;

// variaveis da raquete;
let xraq = 5; yraq = 150; compraq = 5; altraq = 80; 
let colidiu = false;

// velocidade da bola;
let velxbola =4; let velybola =4;

// variaveis do oponente;
let xraqop = 390; yraqop = 150; compraqop = 5; altraqop = 80; let velocidadeyOponente;

function preload(){
  trilha = loadSound("trilha.mp3");
  ponto = loadSound("ponto.mp3");
  raquetada = loadSound("raquetada.mp3");
}

function mostrandoRaquete(x,y){
  rect (x, y, compraq, altraq);
}
function movimentoRaquete(){
  if(keyIsDown (UP_ARROW)){
    yraq-=10;
  }
  if(keyIsDown (DOWN_ARROW)){
    yraq+=10;
  }
}
//function colisaoRaquete(){
  //if (xdabola - raio < xraq + compraq && ydabola - raio < yraq + altraq && ydabola + raio > yraq){
    //velxbola*=-1;
// raquetada.play();
     // subtraindo o raio do xdabola e ydabola para poder pegar como parametro a borda do circulo
    // adicionando o comprimento da raquete em xraq para poder bater no inicio dela
   // y-raio - pega a parte de cima da bola
  // y + raio - pega a de baixo
 // } }
    
function colisaoDasRaquetes(x,y){
  colidiu = collideRectCircle(x , y, compraq, altraq, xdabola, ydabola, raio);
  if(colidiu){
    velxbola *=-1;
    raquetada.play();
  }
}

function movimentaOponente(){
  //é igual ao y da bola menos y do oponente e menos o comprimento do opoenente para a bola sempre tocar em uma determinada bola do oponente. divide por dois e subtrai 30, um pouco mais pra cima (uma margem para marcacao)
  //velocidadeyOponente = ydabola - yraqop - compraqop / 2 - 30;
 // yraqop += velocidadeyOponente;
  // para que ela se mova
  // multiplayer
  if(keyIsDown (87)){
    yraqop-=10;
  }
  if(keyIsDown (83)){
    yraqop+=10;
  }
}

function placar(){
  stroke(255);
  textSize(16);
  textAlign(CENTER)
  fill(color(255, 140, 0));
  rect(100,10,40,20);
  fill(255);
  text(meuspontos,120,26);
  fill(color(255, 140, 0));
  rect(280,10, 40, 20);
  fill(255);
  text(pontosdele, 300, 26);
}
function contagempontos(){
  if(xdabola > 395){
    meuspontos+=1;
    ponto.play();
  }
  if(xdabola < 5){
    pontosdele +=1;
    ponto.play();
  }
}

function aparecebola(){
 circle(xdabola,ydabola, diametro);
}
function velocidadebola(){
  xdabola += velxbola;
  ydabola += velybola;
}
function bordas(){
  // somando raio e subtraindo para que a bola nao entre metade das bordas pois sempre pega o centro como parametro;
  if (xdabola + raio > width || xdabola - raio <0 ){
    velxbola*=-1;
  }
  if (ydabola + raio > height || ydabola - raio <0){
    velybola*=-1;
  }
}
function setup() {
  createCanvas(400, 400);
  trilha.loop();
}

function draw() {
  background (0);
  aparecebola();
  velocidadebola();
  bordas();
  mostrandoRaquete(xraq, yraq);
  movimentoRaquete();
  //colisaoRaquete();
  colisaoDasRaquetes(xraq,yraq);
  mostrandoRaquete(xraqop, yraqop);
  movimentaOponente();
  colisaoDasRaquetes(xraqop,yraqop);
  placar();
  contagempontos();
}